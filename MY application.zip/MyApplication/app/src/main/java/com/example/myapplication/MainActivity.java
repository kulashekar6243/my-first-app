package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;

import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name,age,weight,height;
    Button button,button2;
    TextView textView,bodymassindex;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=findViewById(R.id.name);
        age=findViewById(R.id.age);
        weight=findViewById(R.id.weight);
        height=findViewById(R.id.height);
        button=findViewById(R.id.button);
        button2=findViewById(R.id.button2);
        textView=findViewById(R.id.textView);
        bodymassindex=findViewById(R.id.bodymassindex);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int weigh=Integer.parseInt(weight.getText().toString());
                int heih=Integer.parseInt(height.getText().toString());
                int bodymi=weigh/(heih*heih);
                int bmi=bodymi;
                bodymassindex.setText("your body mass index was :"+bmi);
                if (bmi<23){
                    Toast.makeText(MainActivity.this, "you are at low risk", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "you are at high risk of obesity", Toast.LENGTH_SHORT).show();
                }






            }

        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,com.example.myapplication.activity2.class);
                startActivity(intent);
            }
        });
    }
}
